package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import bean.LoginBean;
import bean.UserBean;

public class UserDAOImpl implements UserDAO {
	Connection con;
	PreparedStatement ps;

	@Override
	public boolean insertUser(UserBean ub) {
		String insertQ = "insert into users(name,address,username, password, state, gender) values(?,?,?,?,?,?)";
		con = MyDBConnection.getConnection();
		try {

			int res = 0;

			ps = con.prepareStatement(insertQ);
			ps.setString(1, ub.getName());
			ps.setString(2, ub.getAddress());
			ps.setString(3, ub.getUsername());
			ps.setString(4, ub.getPassword());
			ps.setString(5, ub.getState());
			ps.setString(6, ub.getGender());

			res = ps.executeUpdate();
			Statement s = con.createStatement();
			s.executeUpdate(
					"create table " + ub.getUsername() + "_cart(product_name varchar(30), cost number, images blob)");

			if (res > 0) {

				return true;
			} else {

				return false;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return false;
	}

	@Override
	public boolean loginValid(LoginBean lb) {
		// TODO Auto-generated method stub
		con = MyDBConnection.getConnection();

		try {
			Statement s = con.createStatement();
			String selectPassword = "select * from Users where username='" + lb.getUsername() + "'";
			ResultSet res = s.executeQuery(selectPassword);
			while (res.next()) {
				if (lb.getPassword().equals(res.getString(4)))
					return true;
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return false;
	}

	@Override
	public boolean feedback(String uname, String feedback) {
		// TODO Auto-generated method stub

		con = MyDBConnection.getConnection();
		boolean res = false;
		try {
			String q = "update users set feedback='" + feedback + "' where username='" + uname + "'";
			Statement stmt = con.createStatement();
			res = stmt.execute(q);

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return res;
	}

	@Override
	public ResultSet cartItems(String username) {
		// TODO Auto-generated method stub
		con = MyDBConnection.getConnection();
		try {
			Statement s = con.createStatement();
			ResultSet rs = s.executeQuery("select product_name,cost from " + username + "_cart");

			return rs;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}

}
