package com;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.UserDAOImpl;

/**
 * Servlet implementation class CartServlet
 */
public class CartServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public CartServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		String username = request.getParameter("username");
		System.out.println(username);
		ResultSet rs = new UserDAOImpl().cartItems(username);
		PrintWriter out = response.getWriter();
		// int sum=0;
		out.print("<html><head><body>");
		out.print("<link rel='stylesheet' href='Styles.css'>");
		out.print("<img alt='' src='544-5440510_shopping-cart.png' align='middle'>");
		out.print("<style>tr,td{color:black;background-color:white}</style>");
		out.print("<table  align='center'>");
		out.print("<tr><th>Product name</th><th>Cost</th>");
		try {

			while (rs.next()) {

				String pro = rs.getString(1);
				int cost = rs.getInt(2);
				out.print("<tr><td color:black>" + pro + "</td><td>" + cost
						+ "</td><td><h3>Buy</h3><a href='Pay.jsp?pro=" + pro + "&cost=" + cost
						+ "'><input type='button' name='buy' value='buy'></a><a href='delete.jsp?pro=" + pro + "&uname="
						+ username + "'><input type='button' name='del' value='Delete'></a></td>");
			}
			out.print("</tr></table>");
			out.print("</body></head></html>");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
