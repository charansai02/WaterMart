 create table users(
 	name varchar2(50) not null,
 	address varchar2(50) not null,
 	username varchar2(20) primary key,
 	password varchar2(10) not null,
 	state varchar2(20) not null,
 	gender varchar2(6) not null,
 	feedback varchar2(500));
 	
 	
 create table smart_filters(
 	product_name varchar2(30),
 	cost number,
 	no_of_items number);
 	
 	
 create table candle_filters(
 	product_type varchar2(30),
 	cost number,
 	no_of_items number);